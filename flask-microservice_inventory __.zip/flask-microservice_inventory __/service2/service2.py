from flask import Flask, jsonify, request

app = Flask(__name__)

# Database in-memory untuk contoh
products = []

@app.route('/products', methods=['GET'])
def get_products():
    return jsonify(products)

@app.route('/products', methods=['POST'])
def create_product():
    product = request.json
    products.append(product)
    return jsonify(product), 201

@app.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    if product_id < len(products):
        products[product_id] = request.json
        return jsonify(products[product_id])
    return jsonify({"error": "Product not found"}), 404

@app.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    if product_id < len(products):
        deleted_product = products.pop(product_id)
        return jsonify(deleted_product)
    return jsonify({"error": "Product not found"}), 404

if __name__ == '__main__':
    app.run(port=5002)