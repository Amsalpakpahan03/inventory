from flask import Flask, jsonify
import requests

app = Flask(__name__)

SERVICE1_URL = "http://localhost:5001/service1"
SERVICE2_URL = "http://localhost:5002/service2"

@app.route('/gateway', methods=['GET'])
def gateway():
    # Ambil data dari Service 1
    response1 = requests.get(SERVICE1_URL)
    data1 = response1.json()

    # Ambil data dari Service 2
    response2 = requests.get(SERVICE2_URL)
    data2 = response2.json()

    # Gabungkan respons
    return jsonify({
        "service1": data1,
        "service2": data2
    })

if __name__ == '__main__':
    app.run(port=5000)  # Jalankan di port 5000