// Fungsi untuk menampilkan stok barang
function loadStok() {
    fetch('/api/barang')
        .then(response => response.json())
        .then(data => {
            const stokList = document.getElementById('stokList');
            stokList.innerHTML = '';
            if (!Array.isArray(data)) {
                console.error("Data stok tidak valid:", data);
                return;
            }
            data.forEach(barang => {
                const li = document.createElement('li');
                li.textContent = `${barang.nama} - ${barang.jumlah} unit (Rp ${barang.harga}/unit)`;
                stokList.appendChild(li);
            });
        })
        .catch(error => console.error("Gagal memuat stok:", error));
}

// Fungsi untuk menambah barang
document.getElementById('tambahBarangForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const nama = document.getElementById('namaBarang').value.trim();
    const jumlah = parseInt(document.getElementById('jumlahBarang').value);
    const harga = parseInt(document.getElementById('hargaBarang').value);

    if (!nama || jumlah <= 0 || harga <= 0) {
        alert("Mohon isi semua data dengan benar!");
        return;
    }

    fetch('/api/barang', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nama, jumlah, harga })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        loadStok();
    })
    .catch(error => console.error("Gagal menambah barang:", error));
});

// Fungsi untuk menambah item ke nota
function tambahItemNota() {
    const notaItems = document.getElementById('notaItems');
    const div = document.createElement('div');
    div.classList.add('nota-item');
    div.innerHTML = `
        <input type="text" placeholder="Nama Barang" required>
        <input type="number" placeholder="Jumlah" required min="1">
        <button type="button" onclick="hapusItemNota(this)">Hapus</button>
    `;
    notaItems.appendChild(div);
}

// Fungsi untuk menghapus item dari nota
function hapusItemNota(button) {
    button.parentElement.remove();
}

// Fungsi untuk membuat dan mendownload nota sebagai PDF
function downloadNotaPDF(nota) {
    if (!nota || !nota.items || nota.items.length === 0) {
        alert("Nota kosong atau tidak valid!");
        return;
    }
    
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Judul Nota
    doc.setFontSize(18);
    doc.text("Nota Pembelian", 10, 10);

    // Tambahkan tanggal
    const tanggal = new Date().toLocaleString();
    doc.setFontSize(10);
    doc.text(`Tanggal: ${tanggal}`, 10, 20);

    // Detail Nota
    doc.setFontSize(12);
    let y = 30;
    nota.items.forEach((item, index) => {
        const harga_per_item = item.harga_total / item.jumlah;
        doc.text(`${index + 1}. ${item.nama_barang} - ${item.jumlah} x Rp ${harga_per_item}`, 10, y);
        y += 10;
    });

    // Total Harga
    doc.setFontSize(14);
    doc.text(`Total Harga: Rp ${nota.total_harga}`, 10, y + 10);

    // Simpan sebagai PDF
    doc.save(`nota_${new Date().getTime()}.pdf`);
}

// Fungsi untuk membuat nota dan mengunduh PDF
document.getElementById('buatNotaForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const items = [];
    document.querySelectorAll('.nota-item').forEach(div => {
        const inputs = div.querySelectorAll('input');
        const nama_barang = inputs[0].value.trim();
        const jumlah = parseInt(inputs[1].value);

        if (!nama_barang || jumlah <= 0) {
            alert("Mohon isi semua data dengan benar!");
            return;
        }

        items.push({ nama_barang, jumlah });
    });

    fetch('/api/nota', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.nota) {
            alert(data.message);
            loadStok();
            downloadNotaPDF(data.nota);
        } else {
            alert("Gagal membuat nota! Cek API backend.");
        }
    })
    .catch(error => console.error('Gagal membuat nota:', error));
});

// Muat stok saat halaman dimuat
loadStok();
