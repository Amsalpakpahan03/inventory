from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient
from bson.objectid import ObjectId
from flask_cors import CORS  # Untuk menghindari masalah CORS

app = Flask(__name__)
CORS(app)  # Aktifkan CORS

# Koneksi ke MongoDB
client = MongoClient('mongodb+srv://ceciljeleq:yV8zKCV04PVK9OFJ@inventorydb.h61ug.mongodb.net/?retryWrites=true&w=majority&appName=inventorydb')  # Ganti dengan URI MongoDB kamu
db = client['inventory_db']  # Nama database
barang_collection = db['barang']  # Collection untuk barang
nota_collection = db['nota']  # Collection untuk nota

# Halaman utama
@app.route('/')
def index():
    return render_template('index.html')

# Endpoint untuk menambah barang
@app.route('/api/barang', methods=['POST'])
def tambah_barang():
    data = request.get_json()
    nama = data.get('nama')
    jumlah = data.get('jumlah')
    harga = data.get('harga')

    if not nama or not jumlah or not harga:
        return jsonify({"error": "Nama, jumlah, dan harga harus diisi"}), 400

    # Cek apakah barang sudah ada
    existing_barang = barang_collection.find_one({"nama": nama})
    if existing_barang:
        # Update stok jika barang sudah ada
        new_jumlah = existing_barang['jumlah'] + int(jumlah)
        barang_collection.update_one(
            {"_id": existing_barang['_id']},
            {"$set": {"jumlah": new_jumlah}}
        )
        return jsonify({"message": "Stok barang berhasil diupdate"}), 200
    else:
        # Tambahkan barang baru
        barang = {
            "nama": nama,
            "jumlah": int(jumlah),
            "harga": float(harga)
        }
        result = barang_collection.insert_one(barang)
        return jsonify({"message": "Barang berhasil ditambahkan", "id": str(result.inserted_id)}), 201

# Endpoint untuk melihat stok barang
@app.route('/api/barang', methods=['GET'])
def lihat_stok():
    barang_list = list(barang_collection.find())
    result = []
    for barang in barang_list:
        result.append({
            "id": str(barang['_id']),  # Konversi ObjectId ke string
            "nama": barang['nama'],
            "jumlah": barang['jumlah'],
            "harga": barang['harga']
        })
    return jsonify(result), 200

# Endpoint untuk membuat nota
@app.route('/api/nota', methods=['POST'])
def buat_nota():
    data = request.get_json()
    items = data.get('items')  # Format: [{"nama_barang": "Barang A", "jumlah": 2}, ...]

    if not items:
        return jsonify({"error": "Items harus diisi"}), 400

    total_harga = 0
    nota_items = []

    for item in items:
        nama_barang = item.get('nama_barang')
        jumlah = int(item.get('jumlah'))  # Pastikan jumlah adalah integer

        # Cari barang di database
        barang = barang_collection.find_one({"nama": nama_barang})
        if not barang:
            return jsonify({"error": f"Barang {nama_barang} tidak ditemukan"}), 404

        if int(barang['jumlah']) < jumlah:
            return jsonify({"error": f"Stok {nama_barang} tidak mencukupi"}), 400

        # Kurangi stok barang
        new_jumlah = int(barang['jumlah']) - jumlah
        barang_collection.update_one(
            {"_id": barang['_id']},
            {"$set": {"jumlah": new_jumlah}}
        )

        # Hitung total harga
        harga_total = jumlah * float(barang['harga'])
        total_harga += harga_total

        # Simpan item ke nota
        nota_items.append({
            "nama_barang": nama_barang,
            "jumlah": jumlah,
            "harga_total": harga_total
        })

    # Simpan nota ke database
    nota = {
        "items": nota_items,
        "total_harga": total_harga
    }
    result = nota_collection.insert_one(nota)
    nota['_id'] = str(result.inserted_id)  # Konversi ObjectId ke string

    return jsonify({
        "message": "Nota berhasil dibuat",
        "nota": {
            "_id": nota["_id"],  # Pastikan ObjectId dikembalikan sebagai string
            "items": nota_items,
            "total_harga": total_harga
        }
    }), 201

# Endpoint untuk melihat semua nota
@app.route('/api/nota', methods=['GET'])
def lihat_nota():
    nota_list = list(nota_collection.find())
    result = []
    for nota in nota_list:
        result.append({
            "id": str(nota['_id']),  # Konversi ObjectId ke string
            "items": nota['items'],
            "total_harga": nota['total_harga']
        })
    return jsonify(result), 200

# Jalankan aplikasi
if __name__ == '__main__':
    app.run(debug=True)
